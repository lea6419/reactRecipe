// AppRoutes.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from  './home';
import About from './about'; 
import Recipes from './recpeis';
import RecipeDetail from './RecipeDetails';
import AddRecipe from './addRecipe';
// ייבוא רכיבים נוספים לפי הצורך

const AppRoutes = () => {
    return (
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/recipes" element={<Recipes />}>
            <Route path=":id" element={<RecipeDetail />} /> {/* כאן מוגדר כ-child */}
            
        </Route>
        <Route path="/addRecipe" element={<AddRecipe />}></Route>
    </Routes>

    );
};

export default AppRoutes;
