// RecipeDetail.js
import React from 'react';
import { useParams } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import recipeStore from './AllRecipes'; // ייבוא ה-Store שלך
import { Recipe } from './models';
import { Box, Grid, Typography } from '@mui/material';

const RecipeDetail = observer(() => {
    const { id } = useParams();
    // const r:Recipe = recipeStore.recipes.find((r: { id: number; }) => r.id === parseInt(id));
    const recipe = recipeStore.recipes.find((r: Recipe) => r.id ===parseInt(id||'0'));

    if (!recipe) {
        return <div>מתכון לא נמצא</div>;
    }

    return (
        <Box sx={{ flexGrow: 1, height: '100vh', padding: 2 }}>
        <Grid container spacing={2} sx={{ height: '100%' }}>
            <Grid item xs={4} sx={{ padding: 2, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                <Typography variant="h6" gutterBottom>רשימת מתכונים</Typography>
        <div>
            <h2>{recipe.title}</h2>
            <p>{recipe.description}</p> {/* הנח שיש לך תיאור במתכון */}
           <p>{recipe.authorId}</p>
        </div>
        </Grid>
        <Grid item xs={8} sx={{ padding: 2, position: 'absolute', bottom: 0, right: 0 }}>
            <Typography variant="h6" gutterBottom>הוראות</Typography>
            <p>{recipe.instructions}</p> {/* הנח שיש לך הוראות במתכון */}
        </Grid>
        </Grid>
        </Box>
    );
});

export default RecipeDetail;
