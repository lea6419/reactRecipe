import { observer } from "mobx-react";
import recipeStore from "./AllRecipes";
import { Link, Outlet } from "react-router-dom";
import { Box, Grid, Typography } from "@mui/material";

const RecipeList = observer(() => {
    return (
        <Box sx={{ flexGrow: 1, height: '100vh', padding: 2 }}>
            <Grid container spacing={2} sx={{ height: '100%' }}>
                <Grid item xs={4} sx={{ padding: 2, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                    <Typography variant="h6" gutterBottom>רשימת מתכונים</Typography>
                    <ul style={{ listStyleType: 'none', padding: 0 }}>
                        {recipeStore.recipes.map((recipe) => (
                            <li key={recipe.id} style={{ marginBottom: '10px' }}>
                                <Link to={`/recipes/${recipe.id}`} style={{ textDecoration: 'none', color: 'blue', fontWeight: 'bold' }}>
                                    {recipe.title}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </Grid>
                <Grid item xs={8} sx={{ padding: 2, position: 'absolute', bottom: 0, right: 0 }}>
  <Outlet />
</Grid>
            </Grid>
        </Box>
    );
});

export default RecipeList;
